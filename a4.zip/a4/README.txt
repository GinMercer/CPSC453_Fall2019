CPSC453 Assignment04
*********************************************************
To compile the CMake file:
(From the directory with "CMakeList.txt")
> mkdir build
> cd build
> cmake ..
> make
> ./Curve

To compile again:
(From the directory with "Makefile")
> make
> ./Curve

********************************************************

How to control my objects:

------KEYBOARD USE----------
>Esc
If you want to close the window, just use the keyboard Key ESC can do this.

>up  (light move up)
>down  (light move down)
>left  (light move left)
>right  (light move right)

>Z  (to delet point)
>X  (to add point)

>C  (to rotate pottery)
>V  (to get curve close)

------MOUSE USE----------
>left   (you can click point)
>move   (move the ponit)


