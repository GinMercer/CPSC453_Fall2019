CPSC453 Assignment03 
*********************************************************
To compile the CMake file:
(From the directory with "CMakeList.txt")
> mkdir build
> cd build
> cmake ..
> make
> ./RayTracing_Simple

To compile again:
(From the directory with "Makefile")
> make
> ./RayTracing_Simple

********************************************************
what i did in the assignment are the basic requirements
spheres, triangle, phong, shadow, reflections.

