CPSC453 Assignment01 part01___Traditional OpenGL
*********************************************************
To compile the CMake file:
(From the directory with "CMakeList.txt")
> mkdir build
> cd build
> cmake ..
> make
> ./Assignment01

To compile again:
(From the directory with "Makefile")
> make
> ./Assignment01

********************************************************

How to control my Cube:

------KEYBOARD USE----------
>1    (This will show you the original cube with no hollow, I call this level one)
>2    (This will show you the cube with one hollow in each side, I call this level two)
>3    (This will show you the cube with nine hollows in each side, I call this level three)
>4    (This will show you the cube with many hollows in each side, I call this level four34)
First, you can use the keyboard. The Key 1 2 3 4: they can control my cube's levels. You can choose the level you want.
>Esc
If you want to close the window, just use the keyboard Key ESC can do this.
>w  (if you use the space, the cube will rotate up around the z-axis)
>s  (if you use the space, the cube will rotate down around the z-axis)


------MOUSE USE----------
>left   (if you use the left button, the cube will rotate around the x-axis)
>right  (if you use the right button, the cube will rotate around the y-axis)
>scroll (if you use the scroll, then you can control how big the cube is or how small the cube is)


